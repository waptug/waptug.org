Canada�s Pet Health Concerns that Benefit from Canadian Pet Health Insurance 

There are two health care issues that might make Canada�s pet owners consider purchasing Canadian Pet Health Insurance for their family pets. Cancer and Tularemia.

Cancer is a type of malignant tumor or growths that invade the surrounding tissues and use the bloodstream to move spread to other parts of the body.  Some cancers reappear even after removal of the offending tumor. Cancer can cause that unless the tumor is removed and any remaining cancer cells properly treated. Because of improvements in veterinary care at nutritional needs family pets are living longer.  As a direct result of the longer life span of family pets wore more cases of cancer are being seen.
	
Signs that the family pet might have cancer are abnormal swellings that continue to grow, sores are a few heel, bleeding or other discharge from body openings, the pet is having a difficult time eating and swallowing, persistent lameness, difficulty breathing, painful urination, chronic coughing, weight loss, fevers, lack of appetite, and stamina.  If you notice your pet experience the any individual or combination of the symptoms you should consult your local veterinarian.
	
In the not so distant past cancer and pets was a virtual kiss of death.  In today's medically advanced world of veterinary medicine your pet�s outcome is more positive.  Early detection followed by timely intervention is the most positive here for your pet's cancer.
	
In some cases simple removal on the tumor is all that is required to other may any cancer cells.  Some types of cancer require or surgery.  The surgery has an excellent success rate with cancers that were detected early on. If your pet has a tumor that is inoperable your veterinarian might suggest radiation, chemical, or biological therapy.
	
Radiation therapy exposes the malignant cells to high level of radiation with the hope that the radiation will kill the cancer cells.  Chemical therapy is medication design to kill the cancer cells.  In particularly aggressive forms of cancer chemical and radiation therapy is used jointly. Other forms of therapies used to treat and comfort your pet when they are diagnosed with cancer are grooming, nutritional support, Soft bedding, pain management, ulcer prevention, and physical therapy. If your pet is diagnosed with cancer discuss treat to the veterinarian and call your pet health care insurance representative to find out what can be done to extend life of your pet.
	
On October 2, 2004 Health Canada issued an advisory about a potential health concern to dwarf and regular hamsters called Tularemia.
	
Tularemia is caused by a bacterial disease that is most commonly seen in wild rodents and rabbits. Although it only happens rarely Tularemia is transferable to humans causing flu like symptoms. Tularemia typically found in all muskrats, squirrels, beavers, rabbit, skunks, dear, bison, foxes, opossums, and woodchucks. Although Tularemia is seldom seen in dogs and cats can be contaminated through water, eating infected rabbits, and being bitten by contaminated ticks. The typical symptoms of Tularemia are fever, a loss of appetite, weakness, and diarrhea.  If the condition is left untreated infected animals frequently died.

The typical treatment plan for pets infected with Tularemia is to first eliminate any infected ticks from your pet�s fur.  After that the drugs Strptomycin and Gentamycin are administered for one to two weeks. Tetracycline and Chloramphencicol have also been used to treat pets diagnosed with Tularemia.  

	
	


